public class Square extends Shape {
  private double sideLength;

  public Square(String color, double sideLength) {
    super(color);
    this.sideLength = sideLength;
    calculateArea();
  }

  public void calculateArea() {
    area = sideLength * sideLength;
  }
}
