public class Shape {
  protected String color;
  protected double area;

  public Shape(String color) {
    this.color = color;
  }

  public double getArea() {
    return area;
  }
}


