public class Circle extends Shape {
  private double radius;

  public Circle(String color, double radius) {
    super(color);
    this.radius = radius;
    calculateArea();
  }

  public void calculateArea() {
    area = Math.PI * radius * radius;
  }
}
